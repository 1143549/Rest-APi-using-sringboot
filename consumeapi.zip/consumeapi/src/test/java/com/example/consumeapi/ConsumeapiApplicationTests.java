package com.example.consumeapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsumeapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
